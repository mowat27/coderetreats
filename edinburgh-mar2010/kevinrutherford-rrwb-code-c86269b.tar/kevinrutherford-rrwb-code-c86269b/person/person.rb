Person = Struct.new('Person', :last, :first, :middle)
